
/*program to act as a simple scientific calculator
inputs: num1,num2
outputs: sum
         product
         mode
         difference
         quote
           sum = num1 + num2
           product = num1 * num2
           difference = num1 - num2
           quote = num1/num2
           mode = num1%num2
*/

#include <stdio.h>
#include <stdlib.h>
int main()
{
  int num1,num2,sum,diff,prod,mod;
    float quot;
    num1 = 200;
    num2 = 56;

    sum = num1 + num2;
    diff= num1 - num2;
    prod = num1 * num2;
    quot =(float)num1 / num2;
    mod = num1 / num2;

      printf("%d + %d = %d \n", num1,num2,sum);
      printf("%d - %d - %d \n",num1,num2,diff);
      printf("%d * %d - %d \n",num1,num2,prod);
      printf("%d - %d - %d \n",num1,num2,mod);

    return 0;
}
